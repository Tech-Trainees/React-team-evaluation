import React from 'react';
import './App.css';
import Post_HOC from './post_HOC';

function App_HOC(){
    return(
        <div>
            <Post_HOC/>
        </div>
    )
}
export default App_HOC