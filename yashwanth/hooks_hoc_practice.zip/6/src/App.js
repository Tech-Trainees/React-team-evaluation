
import './App.css';
import App_HOC from './app_HOC';
import App_HK from './appHK';
import App_RP from './app_RP';

function App() {
  return (
    <div className='maindiv'>
         <App_HK/>
         {/* <App_RP />
         <App_HOC/> */}
        </div>    
  );
}

export default App;