
import './App.css';
import React from 'react';
import Appoint from './appoint';

class App extends React.Component{

  
  render(){
    return (
      <div>
      <Appoint />
      </div>
    )
  }
}
export default App;
