
import './App.css';
import SIP from './sip'


function App() {
  return (
    <div className="App">
     <SIP />
   
    </div>
  );
}

export default App;
