import React from "react"
import './App.css';
import SIPCalculation from "./sipcalc";

class SIP extends React.Component {
    constructor(props){
        super(props);  
        this.state={amount:"",year:"",interest:""} 
        this.handleValue1Change = this.handleValue1Change.bind(this)
        this.handleValue2Change = this.handleValue2Change.bind(this)
        this.handleValue3Change = this.handleValue3Change.bind(this)
    }
    handleValue1Change (e) {
        this.setState({ amount:e.target.value});
    }
    handleValue2Change (e) {
        this.setState({ year:e.target.value});
    }
    handleValue3Change (e) {
        this.setState({ interest:e.target.value});
    }
   


    render(){
    
        return(
        <div>
            <h1 >SIP Calculator - Calculate SIP Returns & Invest in SIP</h1><br/>
            <input className="rad" type="radio" name="goal"/><label for="invest" >I want to Invest</label> &nbsp; &nbsp; &nbsp; &nbsp;
            <input className="rad" type="radio" name="goal" /><label for="goal">I Know my Goal</label><br/><br/>
        <div className="mydiv">
            
            <div className="inputdiv" >
            <label className="lab">I wish to invest per month</label> &nbsp;&nbsp;
            <input type="number" className="box" value={this.state.amount} 
                onChange={this.handleValue1Change}/><br/><br/><br/><br/>
            <label className="lab">No. of years </label> 
                <input type="number" className="box1" value={this.props.value} 
                onChange={this.handleValue2Change}/><br/><br/><br/><br/>
            <label className="lab">Expected Rate of Return </label>&nbsp;&nbsp;
                <input type="number" className="box" value={this.props.value} 
                onChange={this.handleValue3Change}/><br/><br/><br/><br/>
            </div>

          <SIPCalculation value={{amount:this.state.amount,interest:this.state.interest,year:this.state.year}} />
        </div>
        </div>
        )

    }
}
export default SIP;
