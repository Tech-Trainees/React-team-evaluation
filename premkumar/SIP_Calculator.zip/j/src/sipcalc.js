import React from "react"
import './App.css'

class SIPCalculation extends React.Component{
    constructor(props){
        super(props);
        
    }
    render(){
        return (<div className="outdiv" >
                    <h2>Invested Amount <br/><br/> ₹&nbsp; <input type="text" className="outbox" readOnly value=
                        {this.props.value.amount *this.props.value.year * 12 }/>
                    </h2>
                    <h2>Resultant Amount<br/> <br/>₹&nbsp; <input type="text" className="outbox" readOnly  value=
                        {(this.props.value.amount*[(Math.pow(1 + (this.props.value.interest/1200),( this.props.value.year*12))-1) / (this.props.value.interest/1200)]*(1+(this.props.value.interest/1200))).toFixed(2)} /> 
                    </h2>
                </div>
        )
    }
   
}
export default SIPCalculation;