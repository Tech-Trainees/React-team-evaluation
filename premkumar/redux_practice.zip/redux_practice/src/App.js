import React from 'react';
import './App.css';
import CounterComponent from "./Features/Counter"
function App() {
  return (
    <div className="App">
      <header className="App-header">
       <CounterComponent />
      </header>
    </div>
  );
}

export default App;
