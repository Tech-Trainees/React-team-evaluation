import React, { Component } from 'react';
import './App.css';
import Home from './Components/Home';
import "./Components/Css_Component/style.scss"
function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
