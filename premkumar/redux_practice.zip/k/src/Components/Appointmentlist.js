import React from 'react';


function Appointmentlist(props) {
    
    
    function handleEdit(pname,gender,age,pno,date,time,dname,cr)
    {
        props.edit(pname,gender,age,pno,date,time,dname,cr)
    }
    function handleDelete(e)
    {
        props.delete(e)    
        
    }

    
        return(
        <div class="container">
            <br/>
                <br/>

                    <table class="table">
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Status</th>
                                <th>Appointment</th>
                                <th>Phone</th>
                                <th>Doctor</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {props.appointlist.map(item => (

                                    <tr>
                                        <td>
                                            <div class="user-info">
                                                <div class="user-info__img">
                                                    <img src="img/prof.png" alt="User Img"/>
                                                </div>
                                                <div class="user-info__basic">
                                                    <h5 class="mb-0">{item.pname}</h5>
                                                    <p class="text-muted mb-0">{item.age+" yrs "+item.gender}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="btn btn-success">{item.cr}</span>
                                        </td>
                                        <td>
                                            <h6 class="mb-0">{item.time}</h6>
                                            <small>{item.date}</small>
                                        </td>
                                        <td>

                                            <h6 class="mb-0">{item.pno}</h6>
                                            <a href="#!"><small>Contact</small></a>
                                        </td>
                                        <td>
                                            <h6 class="mb-0">{item.dname}</h6>
                                        </td>
                                        
                                            <td>
                                            <button type="button" class="editbtn" onClick={()=>handleEdit(item.pname,item.gender,item.age,item.pno,item.date,item.time,item.dname,item.cr)}>Edit</button>
                                            </td>
                                            <td>
                                            <button type="button" class="deletebtn"  onClick={()=>handleDelete(item.pname)}>Delete</button>
                                            </td>
             
                                        
                                    </tr>
                                    ))
                      
                        }
                        </tbody>
                    </table>
                </div>

        )
    }


export default Appointmentlist