import './Css_Component/css/style.css'
import React, { useState } from 'react';
import Appointmentlist from './Appointmentlist'
import {AppointmentSlice} from './AppointmenSlice'
import { useSelector, useDispatch } from 'react-redux'


 function Home(){
 
    const [list,setlist]= useState({})
  
   const UserAppointmentlist = useSelector((state) => {
   return state.Appointment.UserAppointmentlist});

function handleInputChange(event){
    const target = event.target;
    const value = target.value;
    const name = target.name;
    setlist({ ...list, [name]: value  });
  }


const dispatch = useDispatch();
  
const patientbook = () => {
        dispatch(AppointmentSlice.actions.add({user:{"pname":list.pname,"gender":list.gender,"age":list.age,"pno":list.pno,"date":list.date,"time":list.time,"dname":list.dname,"cr":list.cr}}));
        setlist({"pname":"","gender":"","age":"","pno":"","date":"","time":"","dname":"","cr":""})        
}

const deletepatient = (val) => {
    dispatch(AppointmentSlice.actions.delete({id:val}))

}

const editpatient=(pname,gender,age,pno,date,time,dname,cr)=>{
    setlist({"pname":pname,"gender":gender,"age":age,"pno":pno,"date":date,"time":time,"dname":dname,"cr":cr})
    
    dispatch(AppointmentSlice.actions.update({id:pname}))

}


    return (
        <div>
        <section class="form-content">
        <div class="container register-form">
                    <div class="form">
                        <div class="note">
                            <p>Welcome to Gradious Doctor Appointment Booking</p>
                        </div>
        
                        <div class="form-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control"  placeholder="Patient Name *" name='pname' value={list.pname} onChange={handleInputChange}/>
                                    </div>
                                    <div class="form-group">
                                        <select  class="form-control" placeholder="Select Male/Female *" name='gender' value={list.gender} onChange={handleInputChange}>
                                        <option name="M">Male</option>
                                        <option name="F">Female</option> 
                                        </select>                               
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Age *" name='age' value={list.age} onChange={handleInputChange}/>
                                    </div>
        
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Phone Number *" name='pno' value={list.pno} onChange={handleInputChange}/>
                                    </div>
                                    <div class="form-group">
                                        <input type="date" class="form-control" placeholder="Date *" name='date' value={list.date} onChange={handleInputChange}/>
                                    </div>
        
                                    <div class="form-group">
                                        <input type="time" class="form-control" placeholder="Time *" name='time' value={list.time} onChange={handleInputChange}/>
                                    </div>
        
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Doctor Name *" name='dname' value={list.dname} onChange={handleInputChange}/>
                                    </div>
                                    <div class="form-group">
                                        <select  class="form-control" placeholder="Select Consule/Revisit *" name='cr' value={list.cr} onChange={handleInputChange}>
                                        <option name="Consult">Consult</option>
                                        <option name="Revisit">Revisit</option> 
                                        </select>                               
        
                                    </div>
                                </div>
        
                            </div>
                            <button type="button" class="btnSubmit" onClick={patientbook} >Book Appointment</button>
                        </div>
                    </div>
                </div>
            </section>
             
               
            <Appointmentlist appointlist={UserAppointmentlist} 
            delete={deletepatient} edit={editpatient} />
            </div>
            
        
    );
  }


export default Home
